public class border {
    int length = 1000;
    int width;
}
