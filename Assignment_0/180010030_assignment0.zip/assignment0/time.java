public class time {
    int t = 0;
    
}
