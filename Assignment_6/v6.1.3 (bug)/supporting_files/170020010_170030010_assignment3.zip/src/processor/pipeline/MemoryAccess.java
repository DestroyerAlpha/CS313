package processor.pipeline;

import processor.Processor;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		//TODO
		if (EX_MA_Latch.isMA_enable()) {
			int opcode = EX_MA_Latch.getOpcode();
			int rd = EX_MA_Latch.getrd();
			int ALUResult = EX_MA_Latch.getALUResult();
			int op1 = EX_MA_Latch.getop1();
			int reg2 = EX_MA_Latch.getreg2();
			int ldResult = -1;
			int remainder = EX_MA_Latch.getremainder();
			// Load:
			if (opcode == 22) {
				// Address = ALUResult
				// Register to be written into = op2
				ldResult = containingProcessor.getMainMemory().getWord(ALUResult);
				//containingProcessor.getRegisterFile().setValue(reg2, data);
			}
			// Store:
			else if (opcode == 23) {
				// Address = ALUResult
				// Value to be written = op1
				containingProcessor.getMainMemory().setWord(ALUResult, op1);
			}
			
			MA_RW_Latch.setALUResult(ALUResult);
			MA_RW_Latch.setldResult(ldResult);
			MA_RW_Latch.setOpcode(opcode);
			MA_RW_Latch.setreg2(reg2);
			MA_RW_Latch.setrd(rd);
			MA_RW_Latch.setremainder(remainder);
			
			EX_MA_Latch.setMA_enable(false);
			MA_RW_Latch.setRW_enable(true);
		}
	}

}
