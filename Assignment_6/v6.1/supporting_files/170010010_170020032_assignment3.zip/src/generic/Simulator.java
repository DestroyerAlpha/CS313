package generic;

import java.io.*;

import processor.Clock;
import processor.Processor;

public class Simulator {
		
	static Processor processor;
	static boolean simulationComplete;
	
	public static void setupSimulation(String assemblyProgramFile, Processor p)
	{
		Simulator.processor = p;
		loadProgram(assemblyProgramFile);
		
		simulationComplete = false;
	}
	
	static void loadProgram(String assemblyProgramFile)
	{
		/*
		 * TODO
		 * 1. load the program into memory according to the program layout described
		 *    in the ISA specification
		 */    
		try(
				InputStream osf = new BufferedInputStream(new FileInputStream(assemblyProgramFile));
			)
		{
			DataInputStream writeB = new DataInputStream(osf);

			int len;
			String temp;
			String ins = "";
			int count = 0;
			int data;
			int PC;

			while(writeB.available() > 0)
			{
				ins = "";
				int in = writeB.readInt();

				String a = Integer.toBinaryString(in);
				
				len = a.length();
				temp = "";
				for(int i=len; i<32; i++)
					temp = temp + "0";
				a = temp + a;
				
				ins = ins + a;	
				
				/* 2. set PC to the address of the first instruction in the main
				 */
				
				if(count == 0)
				{
					PC = Integer.parseUnsignedInt(ins, 2);

					processor.getRegisterFile().setProgramCounter(PC);
					count++;
					continue;
				}
				
				data = Integer.parseUnsignedInt(ins, 2);

				processor.getMainMemory().setWord(count - 1, data);
				count++;		
			}

			count -= 1;
			
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		
		//setSimulationComplete(true);
		
		/* 3. set the following registers:
		 *     x0 = 0
		 *     x1 = 65535
		 *     x2 = 65535
		 */

		processor.getRegisterFile().setValue(0, 0);
		processor.getRegisterFile().setValue(1, 65535);
		processor.getRegisterFile().setValue(2, 65535);	
	}
	
	public static void simulate()
	{
		while(simulationComplete == false)
		{
			processor.getIFUnit().performIF();
			Clock.incrementClock();
			
			int ins = Statistics.getNumberOfInstructions();
			ins = ins + 1;
			Statistics.setNumberOfInstructions(ins);
			
			long clock = Clock.getCurrentTime();
			Statistics.setNumberOfCycles((int) clock);
			
			if(simulationComplete == true)
			{
				break;
			}
			processor.getOFUnit().performOF();
			Clock.incrementClock();
			processor.getEXUnit().performEX();
			Clock.incrementClock();
			processor.getMAUnit().performMA();
			Clock.incrementClock();
			processor.getRWUnit().performRW();
			Clock.incrementClock();
		}	
		
		// TODO
		// set statistics
	}
	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}
}
