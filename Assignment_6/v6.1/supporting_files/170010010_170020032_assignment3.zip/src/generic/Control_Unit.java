package generic;

import processor.Processor;

public class Control_Unit {
		
	static Processor processor;
	static boolean simulationComplete;
	
	static int is_Store = 0;
	static int is_Load = 0;
	static int is_Write_Back = 0;
	static int is_Branch_Target = 0;
	static int is_Immediate = 0;
	static int is_Add = 0;
	static int is_Subtract = 0;
	static int is_Multiply = 0;
	static int is_Divide = 0;
	static int is_And = 0;
	static int is_Or = 0;
	static int is_Xor = 0;
	static int is_Slt = 0;
	static int is_Sll = 0;
	static int is_Srl = 0;
	static int is_Sra = 0;
	static int is_End = 0;
	static int is_Jmp = 0;
	static int is_Beq = 0;
	static int is_Bne = 0;
	static int is_Blt = 0;
	static int is_Bgt = 0;
	
	
	public static int get_is_Store()
	{
		return is_Store;
	}
	
	public static int get_is_Load()
	{
		return is_Load;
	}
	
	public static int get_is_Write_Back()
	{
		return is_Write_Back;
	}
	
	public static int get_is_Branch_Target()
	{
		return is_Branch_Target;
	}
	
	public static int get_is_Immediate()
	{
		return is_Immediate;
	}
	
	public static int get_is_Add()
	{
		return is_Add;
	}
	
	public static int get_is_Subtract()
	{
		return is_Subtract;
	}
	
	public static int get_is_Multiply()
	{
		return is_Multiply;
	}
	
	public static int get_is_Divide()
	{
		return is_Divide;
	}
	
	public static int get_is_And()
	{
		return is_And;
	}
	
	public static int get_is_Or()
	{
		return is_Or;
	}
	
	public static int get_is_Xor()
	{
		return is_Xor;
	}
	
	public static int get_is_Slt()
	{
		return is_Slt;
	}
	
	public static int get_is_Sll()
	{
		return is_Sll;
	}
	
	public static int get_is_Srl()
	{
		return is_Srl;
	}
	public static int get_is_Sra()
	{
		return is_Sra;
	}

	public static int get_is_End()
	{
		return is_End;
	}

	public static int get_is_Jmp()
	{
		return is_Jmp;
	}

	public static int get_is_Beq()
	{
		return is_Beq;
	}

	public static int get_is_Bne()
	{
		return is_Bne;
	}

	public static int get_is_Blt()
	{
		return is_Blt;
	}

	public static int get_is_Bgt()
	{
		return is_Bgt;
	}
	
	public static void set_opcode(String opcode)
	{
		is_Store = 0;
		is_Load = 0;
		is_Write_Back = 0;
		is_Branch_Target = 0;
		is_Immediate = 0;
		is_Add = 0;
		is_Subtract = 0;
		is_Multiply = 0;
		is_Divide = 0;
		is_And = 0;
		is_Or = 0;
		is_Xor = 0;
		is_Slt = 0;
		is_Sll = 0;
		is_Srl = 0;
		is_Sra = 0;
		is_End = 0;
		is_Jmp = 0;
		is_Beq = 0;
		is_Bne = 0;
		is_Blt = 0;
		is_Bgt = 0;
		
		int op_code = Integer.parseUnsignedInt(opcode, 2);

		if(op_code >= 0 && op_code <= 21)
		{
			is_Write_Back = 1;
			int opc = op_code / 2;

			if(op_code % 2 == 0)
			{
				is_Immediate = 0;
			}
			else
			{
				is_Immediate = 1;
			}
			if(opc == 0)
			{
				is_Add = 1;
			}
			else if(opc == 1)
			{
				is_Subtract = 1;
			}
			else if(opc == 2)
			{
				is_Multiply = 1;
			}
			else if(opc == 3)
			{
				is_Divide = 1;
			}
			else if(opc == 4)
			{
				is_And = 1;
			}
			else if(opc == 5)
			{
				is_Or = 1;
			}
			else if(opc == 6)
			{
				is_Xor = 1;
			}
			else if(opc == 7)
			{
				is_Slt = 1;
			}
			else if(opc == 8)
			{
				is_Sll = 1;
			}
			else if(opc == 9)
			{
				is_Srl = 1;
			}
			else if(opc == 10)
			{
				is_Sra = 1;
			}
		}
		else if(op_code == 22)
		{
			is_Load = 1;
			is_Write_Back = 1;
			is_Immediate = 1;
		}
		else if(op_code == 23)
		{
			is_Store = 1;
			is_Write_Back = 0;
			is_Immediate = 1;
		}
		else if(op_code >=24 && op_code <= 28)
		{
			is_Branch_Target = 1;
			is_Write_Back = 0;
			if(op_code == 24)
			{
				is_Jmp = 1;
			}
			else if(op_code == 25)
			{
				is_Beq = 1;
			}
			else if(op_code == 26)
			{
				is_Bne = 1;
			}
			else if(op_code == 27)
			{
				is_Blt = 1;
			}
			else if(op_code == 28)
			{
				is_Bgt = 1;
			}
		}
		else if(op_code == 29)
		{
			is_End = 1;
		}
	}
}
