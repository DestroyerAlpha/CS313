package processor.pipeline;

import generic.Control_Unit;
import processor.Processor;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		if(MA_RW_Latch.isRW_enable())
		{
			//TODO
			
			int ldResult = MA_RW_Latch.getLdResult();
			int newInstruction = MA_RW_Latch.getInstruction();
			int aluResult = MA_RW_Latch.getAluResult();
			int result;

			String ins = Integer.toBinaryString(newInstruction);
			
			int len_ins = ins.length();
			String temp_ins ="";

			for(int i=len_ins; i<32; i++)
				temp_ins = temp_ins + "0";

			ins = temp_ins + ins;

			String rs2 = ins.substring(10, 15);

			String rd = ins.substring(15, 20);

			if(Control_Unit.get_is_Load() == 1)
			{
				result = ldResult;
				containingProcessor.getRegisterFile().setValue(Integer.parseUnsignedInt(rs2, 2), result);
			}
			else if(Control_Unit.get_is_Write_Back() == 1)
			{
				result = aluResult;
				if(Control_Unit.get_is_Immediate() == 1)
				{
					containingProcessor.getRegisterFile().setValue(Integer.parseUnsignedInt(rs2, 2), result);		
				}
				else
				{
					containingProcessor.getRegisterFile().setValue(Integer.parseUnsignedInt(rd, 2), result);
				}
			}
			
			// if instruction being processed is an end instruction, remember to call Simulator.setSimulationComplete(true);

			MA_RW_Latch.setRW_enable(false);
			IF_EnableLatch.setIF_enable(true);
		}
	}

}
