package processor.pipeline;

import generic.Control_Unit;
import processor.Processor;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		if(EX_MA_Latch.isMA_enable())
		{
			//TODO

			int op1 = EX_MA_Latch.getOp1();
			int aluResult = EX_MA_Latch.getAluResult();
			int newPC = EX_MA_Latch.getPC();
			int ldResult = 0;
			int newInstruction = EX_MA_Latch.getInstruction();
			
			if(Control_Unit.get_is_Load() == 1)
			{
				ldResult = containingProcessor.getMainMemory().getWord(aluResult);				
			}
			else if(Control_Unit.get_is_Store() == 1)
			{
				containingProcessor.getMainMemory().setWord(aluResult, op1);
			}
			
			MA_RW_Latch.setLdResult(ldResult);
			MA_RW_Latch.setPC(newPC);
			MA_RW_Latch.setInstruction(newInstruction);
			MA_RW_Latch.setAluResult(aluResult);
			
			EX_MA_Latch.setMA_enable(false);
			MA_RW_Latch.setRW_enable(true);
		}
	}

}
