package processor.pipeline;

import generic.Control_Unit;
import processor.Processor;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performEX()
	{
		if(OF_EX_Latch.isEX_enable())
		{
			//TODO
			
			int branchTarget = OF_EX_Latch.getBranchTarget();
			int immediate = OF_EX_Latch.getImmediate();
			int op1 = OF_EX_Latch.getOp1();
			int op2 = OF_EX_Latch.getOp2();
			int newPC = OF_EX_Latch.getPC();
			int newInstruction = OF_EX_Latch.getInstruction();

			long long_aluResult = 0;
			int aluResult = 0;
			int x31Result = 0;
			int branchPC = 1;
			
			if(Control_Unit.get_is_Immediate() == 1)
			{
				if(Control_Unit.get_is_Add() == 1)
				{
					long_aluResult = op1 + immediate;
				}
				else if(Control_Unit.get_is_Subtract() == 1)
				{
					long_aluResult = op1 - immediate;
				}
				else if(Control_Unit.get_is_Multiply() == 1)
				{
					long_aluResult = op1 * immediate;
				}
				else if(Control_Unit.get_is_Divide() == 1)
				{
					long_aluResult = op1 / immediate;
					x31Result = op1 % immediate;
					containingProcessor.getRegisterFile().setValue(31, x31Result);
				}
				else if(Control_Unit.get_is_And() == 1)
				{
					long_aluResult = op1 & immediate;
				}
				else if(Control_Unit.get_is_Or() == 1)
				{
					long_aluResult = op1 | immediate;
				}
				else if(Control_Unit.get_is_Xor() == 1)
				{
					long_aluResult = op1 ^ immediate;
				}
				else if(Control_Unit.get_is_Slt() == 1)
				{
					if(op1 < immediate)
					{
						long_aluResult = 1;						
					}
					else
					{
						long_aluResult = 0;						
					}
				}
				else if(Control_Unit.get_is_Sll() == 1)
				{
					long_aluResult = op1 << immediate;
				}
				else if(Control_Unit.get_is_Srl() == 1)
				{
					long_aluResult = op1 >>> immediate;
				}
				else if(Control_Unit.get_is_Sra() == 1)
				{
					long_aluResult = op1 >> immediate;
				}
				else if(Control_Unit.get_is_Load() == 1)
				{
					long_aluResult = op1 + immediate;
				}
				else if(Control_Unit.get_is_Store() == 1)
				{
					long_aluResult = op2 + immediate;
				}
			}
			else if(Control_Unit.get_is_Immediate() == 0 && Control_Unit.get_is_Branch_Target() != 1)
			{
				if(Control_Unit.get_is_Add() == 1)
				{
					long_aluResult = op1 + op2;
				}
				else if(Control_Unit.get_is_Subtract() == 1)
				{
					long_aluResult = op1 - op2;
				}
				else if(Control_Unit.get_is_Multiply() == 1)
				{
					long_aluResult = op1 * op2;
				}
				else if(Control_Unit.get_is_Divide() == 1)
				{
					long_aluResult = op1 / op2;
					x31Result = op1 % op2;			
					containingProcessor.getRegisterFile().setValue(31, x31Result);
				}
				else if(Control_Unit.get_is_And() == 1)
				{
					long_aluResult = op1 & op2;
				}
				else if(Control_Unit.get_is_Or() == 1)
				{
					long_aluResult = op1 | op2;
				}
				else if(Control_Unit.get_is_Xor() == 1)
				{
					long_aluResult = op1 ^ op2;
				}
				else if(Control_Unit.get_is_Slt() == 1)
				{
					if(op1 < op2)
					{
						long_aluResult = 1;						
					}
					else
					{
						long_aluResult = 0;						
					}
				}
				else if(Control_Unit.get_is_Sll() == 1)
				{
					long_aluResult = op1 << op2;
				}
				else if(Control_Unit.get_is_Srl() == 1)
				{
					long_aluResult = op1 >>> op2;
				}
				else if(Control_Unit.get_is_Sra() == 1)
				{
					long_aluResult = op1 >> op2;
				}
			}
			else if(Control_Unit.get_is_Branch_Target() == 1)
			{
				if(Control_Unit.get_is_Jmp() == 1)
				{
					branchPC = branchTarget;
				}
				else if(Control_Unit.get_is_Beq() == 1)
				{
					if(op1 == op2)
					{
						branchPC = immediate;
					}
					else
					{
						branchPC = 1;
					}
				}
				else if(Control_Unit.get_is_Bne() == 1)
				{
					if(op1 != op2)
					{
						branchPC = immediate;
					}
					else
					{
						branchPC = 1;
					}
				}
				else if(Control_Unit.get_is_Blt() == 1)
				{
					if(op1 < op2)
					{
						branchPC = immediate;
					}
					else
					{
						branchPC = 1;
					}
				}
				else if(Control_Unit.get_is_Bgt() == 1)
				{
					if(op1 > op2)
					{
						branchPC = immediate;
					}
					else
					{
						branchPC = 1;
					}
				}
				
				EX_IF_Latch.setIF_enable(true);
				EX_IF_Latch.set_branchPC(branchPC);
			}
			
			String lar = Long.toBinaryString(long_aluResult);

			String ar = "";
			String llar = "";
			if(lar.length() > 32)
			{
				ar = lar.substring(32);
				llar = lar.substring(0, 32);
			}

			if(ar.length() != 0)
			{
				x31Result = Integer.parseUnsignedInt(ar, 2);
				aluResult = Integer.parseUnsignedInt(llar, 2);
			}
			else
			{
				x31Result = 0;
				aluResult = (int) long_aluResult;
			}

			EX_MA_Latch.setOp1(op1);
			EX_MA_Latch.setOp2(op2);
			EX_MA_Latch.setAluResult(aluResult);
			EX_MA_Latch.setPC(newPC);
			EX_MA_Latch.setInstruction(newInstruction);
			
			OF_EX_Latch.setEX_enable(false);
			EX_MA_Latch.setMA_enable(true);
		}
	}

}
