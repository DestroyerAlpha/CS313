package processor.pipeline;

import generic.Control_Unit;
import generic.Simulator;
import processor.Processor;
import processor.Clock;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{
		if(IF_EnableLatch.isIF_enable())
		{
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			int branchPC;
			int newPC;

			if(Clock.getCurrentTime() != 0)
			{
				if(EX_IF_Latch.isIF_enable())
				{
					if(Control_Unit.get_is_Branch_Target() == 1)
					{
						branchPC = EX_IF_Latch.get_branchPC();
						newPC = currentPC + branchPC;
					}
					else
					{
						newPC = currentPC + 1;
					}
				}
				else
				{
					newPC = currentPC + 1;
				}
	
				containingProcessor.getRegisterFile().setProgramCounter(newPC);
				
				currentPC = containingProcessor.getRegisterFile().getProgramCounter();
				int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
				
				IF_OF_Latch.setInstruction(newInstruction);
				IF_OF_Latch.setPC(newPC);
								
				IF_EnableLatch.setIF_enable(false);
				EX_IF_Latch.setIF_enable(false);
				IF_OF_Latch.setOF_enable(true);
			}
			else
			{
				int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
				
				IF_OF_Latch.setInstruction(newInstruction);
				
				IF_EnableLatch.setIF_enable(false);
				EX_IF_Latch.setIF_enable(false);
				IF_OF_Latch.setOF_enable(true);
			}
			
			if(Control_Unit.get_is_End() == 1)
			{
				Simulator.setSimulationComplete(true);
			}
		}
	}

}
