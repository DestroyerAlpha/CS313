package processor.pipeline;

public class EX_IF_LatchType {
	
	boolean IF_enable;
	int branchPC = 1;
	
	public EX_IF_LatchType()
	{
		IF_enable = false;
	}
	
	public boolean isIF_enable() {
		return IF_enable;
	}

	public void setIF_enable(boolean IF_enable) {
		this.IF_enable = IF_enable;
	}

	public int get_branchPC()
	{
		return branchPC;
	}
	
	public void set_branchPC(int branchPC)
	{
		this.branchPC = branchPC;
	}

}
