package processor.pipeline;

import generic.Control_Unit;
import processor.Processor;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	
	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{
			//TODO

			int newInstruction = IF_OF_Latch.getInstruction();
			int newPC = IF_OF_Latch.getPC();

			String ins = Integer.toBinaryString(newInstruction);
			
			int len_ins = ins.length();
			String temp_ins ="";

			for(int i=len_ins; i<32; i++)
				temp_ins = temp_ins + "0";
			
			ins = temp_ins + ins;
			
			String opcode = ins.substring(0, 5);
			
			Control_Unit.set_opcode(opcode);
			
			String imm = ins.substring(15, 32);

			int len_imm = imm.length();
			String temp_imm ="";

			for(int i=len_imm; i<32; i++)
				temp_imm = temp_imm + imm.charAt(0);
			
			imm = temp_imm + imm;
			
			String offset = ins.substring(10, 32);
			
			int len = offset.length();
			String temp ="";

			for(int i=len; i<32; i++)
				temp = temp + offset.charAt(0);
			
			offset = temp + offset;
			
			int branchTarget = Integer.parseUnsignedInt(offset, 2);

			String rs1 = ins.substring(5, 10);

			String rs2 = ins.substring(10, 15);

			int port1;
			int port2;
			
			port1 = Integer.parseUnsignedInt(rs1, 2);
			
			port2 = Integer.parseUnsignedInt(rs2, 2);

			int op1 = containingProcessor.getRegisterFile().getValue(port1);
			int op2 = containingProcessor.getRegisterFile().getValue(port2);

			OF_EX_Latch.setBranchTarget(branchTarget);
			OF_EX_Latch.setImmediate(Integer.parseUnsignedInt(imm, 2));
			OF_EX_Latch.setOp1(op1);
			OF_EX_Latch.setOp2(op2);
			OF_EX_Latch.setPC(newPC);
			OF_EX_Latch.setInstruction(newInstruction);
			
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}
